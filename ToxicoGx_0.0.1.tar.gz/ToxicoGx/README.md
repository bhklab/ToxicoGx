# ToxicoGx
A statistical package, in R, used in cancer research to analyze toxicity of drugs on cancer gene expression across large-scale toxicogenomic datasets.
